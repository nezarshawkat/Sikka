import { Capacitor, registerPlugin } from "@capacitor/core";

export type AdPlacement = "location_loaded" | "trip_review_complete";

type NativeAdMobPlugin = {
  showInterstitial(options: { placement: AdPlacement }): Promise<{ shown: boolean; reason?: string }>;
  preload(): Promise<void>;
};

const SikkaAdMob = registerPlugin<NativeAdMobPlugin>("SikkaAdMob");

/** Shows the preloaded native AdMob interstitial when one is ready. */
export async function showInterstitialAd(placement: AdPlacement): Promise<boolean> {
  if (Capacitor.getPlatform() !== "android") return false;
  try {
    const result = await SikkaAdMob.showInterstitial({ placement });
    if (!result.shown) console.info('[SikkaAdMob]', placement, result.reason ?? 'unavailable');
    return result.shown;
  } catch (error) {
    console.warn('[SikkaAdMob] Native request failed', error);
    // An unavailable ad must never interrupt location or trip completion.
    return false;
  }
}

export function preloadInterstitialAd(): void {
  if (Capacitor.getPlatform() === "android") void SikkaAdMob.preload().catch(() => {});
}
