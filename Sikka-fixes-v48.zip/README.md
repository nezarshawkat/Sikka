# Sikka Android startup, ads and route publishing fixes

Prepared from nezarshawkat/Sikka main, commit `08eaccf68ca77f36f6b7a302002e3695cecd29e4`.
This is a source update to apply to that repository. It is not an APK or a signed Play release.

## Apply

1. Extract this ZIP outside your Sikka repository.
2. With Node.js installed, run:

   ```sh
   node /path/to/extracted/apply.mjs /path/to/Sikka --check
   node /path/to/extracted/apply.mjs /path/to/Sikka
   ```

   On Windows, quote paths containing spaces, for example:

   ```powershell
   node "C:\Downloads\Sikka-fixes\apply.mjs" "C:\Projects\Sikka"
   ```

The script checks every file before writing, refuses conflicting newer edits, skips files already updated, and creates a dated source backup in your repository. If your source differs, merge the matching files from `changes/` instead. Do not upload the backup directory to GitHub.

## Deploy both parts

1. Commit the changed source files, excluding the backup directory. No database migration or route reseeding is needed for this patch.
2. Deploy/restart the **backend** with these changes using your existing Render deployment and database configuration. Its build command remains `pnpm run build:backend`.
3. Build the **Android app** using the existing `Build Android Release AAB` GitHub workflow and your existing signing secrets. The new version is **versionCode 48 / versionName 1.0.47**. If Play already has code 48 or higher, increase the code before building.
4. Run the included **Android Startup Smoke Test** workflow (GitHub → Actions → Run workflow). It compiles and launches the app on Android API 29 and 35; it needs no release signing secrets. It does not replace testing the signed release through Play internal testing.
5. Upload the new signed AAB to Play internal testing first. Verify cold launch and the three ad placements, then publish it to users. Existing installed binaries need this Play update; a backend deploy cannot repair native code already installed on phones.

For a local Android build, use Node 24, pnpm 10.28.1, JDK 21 and Android SDK 36:

```sh
pnpm install --frozen-lockfile
pnpm --filter @workspace/sikka run build:mobile
pnpm --filter @workspace/sikka exec cap sync android
cd artifacts/sikka/android
./gradlew assembleDebug
```

Use `gradlew.bat` on Windows. The original workspace excludes Windows Rollup/esbuild binaries; use the existing Linux GitHub build workflow unless you have enabled those development dependencies locally. This patch does not alter the lockfile or those platform overrides.

## What changed

- **Android startup:** removed eager AdMob initialization from Capacitor plugin construction; initialization, callbacks, loading and showing now run on the main thread, with lifecycle checks and handled SDK exceptions. The discovery location service also checks permission before foreground promotion and handles Android rejecting its restart.
- **Ads:** preload after the UI mounts, wait up to eight seconds for a cold placement, retry failed loads with backoff, expire old cached ads, and return actual show callbacks with diagnostic reasons. Location ads no longer wait for reverse geocoding; they are deduplicated per successful session. Trip completion shows an ad after either submitting or skipping the review; cancelling also requests an ad. The public config lookup cannot wait indefinitely for authentication or the backend.
- **Publishing:** accepting a route activates both database flags, while rejecting/deactivating removes it from published data. Publishing requires valid geometry. Full snapshots are authoritative even when deletion lowers their maximum timestamp, and content hashes detect edits beyond timestamps/counts. Polling every 30 seconds while visible, plus startup/resume/online refreshes, updates each connected app. The planner and dashboard read the same cache. Updated routes remain available offline after synchronization; removed routes are removed from the cache. Route direction and governorate metadata are preserved. Admins can still open inactive routes for editing.

## Verify after deployment

- Fresh installation and upgrade installation: launch on multiple physical devices, then background/reopen. Test with location denied and with location granted.
- Debug builds use Google's **test interstitial** unit. Production builds retain your existing AdMob app and ad-unit IDs. Test the signed release on registered AdMob test devices; never click live ads for testing.
- Obtain location, finish a trip with a submitted review, finish with Skip, and cancel a trip. Check `adb logcat -s SikkaAdMob SikkaDiscovery AndroidRuntime` if an ad does not show. A `shown: false`/`load_failed` result is distinguishable from a JavaScript request failure. Ad inventory, account approval, consent configuration and network availability are controlled by AdMob; source code cannot guarantee a filled ad request.
- On account/device A accept a discovery route with valid geometry. Keep device B online and open for up to roughly 30 seconds, then plan a trip using that corridor. Edit its fare/geometry on A and repeat on B. Disable/delete it and confirm B no longer uses it. Repeat offline after a successful sync to verify persistence.

## Validation and limits

See `VERIFICATION.md` for checks actually run and remaining device verification. The supplied Play crash stack trace was not available, so the patch fixes identified Android crash paths without claiming that a specific production stack trace has been reproduced.

To undo, restore the files from the dated backup, and remove only the new files listed in its `backup-manifest.json`. Keep your existing signing credentials, deployment settings and database.

References: [Google interstitial threading and lifecycle guidance](https://developers.google.com/admob/android/interstitial), [Android emulator runner](https://github.com/ReactiveCircus/android-emulator-runner).
