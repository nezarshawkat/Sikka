import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const packageDir = path.dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const checkOnly = args.includes('--check');
const root = fs.realpathSync(path.resolve(args.find(arg => !arg.startsWith('--')) ?? process.cwd()));
const manifest = JSON.parse(fs.readFileSync(path.join(packageDir, 'manifest.json'), 'utf8'));
const hash = bytes => crypto.createHash('sha256').update(bytes.toString('utf8').replaceAll('\r\n', '\n')).digest('hex');
if (!fs.existsSync(path.join(root, 'artifacts/sikka/package.json'))) throw new Error('Specify the Sikka repository root, containing artifacts/sikka/package.json.');

function targetFor(relative) {
  const target = path.resolve(root, relative);
  if (!target.startsWith(root + path.sep)) throw new Error('Invalid package path: ' + relative);
  // Never follow a checkout symlink outside the selected repository.
  let ancestor = target;
  while (!fs.existsSync(ancestor)) ancestor = path.dirname(ancestor);
  const actual = fs.realpathSync(ancestor);
  if (actual !== root && !actual.startsWith(root + path.sep)) throw new Error('Path leaves the repository: ' + relative);
  return target;
}

const pending = [];
const conflicts = [];
for (const file of manifest.files) {
  const target = targetFor(file.path);
  const replacement = fs.readFileSync(path.join(packageDir, 'changes', file.path));
  if (hash(replacement) !== file.newHash) throw new Error('Package integrity check failed: ' + file.path);
  const currentHash = fs.existsSync(target) ? hash(fs.readFileSync(target)) : null;
  if (currentHash === file.newHash) continue;
  if (currentHash !== file.oldHash) conflicts.push(file.path);
  else pending.push({ ...file, target, replacement });
}
if (conflicts.length) {
  console.error('Nothing changed. These files differ from the source version used for this fix:\n' + conflicts.join('\n'));
  console.error('Merge the matching files from changes/ manually; do not overwrite your newer edits.');
  process.exit(1);
}
if (checkOnly || !pending.length) {
  console.log(pending.length ? `Check passed: ${pending.length} files ready to apply.` : 'All fixes are already applied.');
  process.exit(0);
}
const backup = path.join(root, 'sikka-fix-backup-' + new Date().toISOString().replace(/[:.]/g, '-'));
fs.mkdirSync(backup, { recursive: true });
for (const file of pending) {
  if (fs.existsSync(file.target)) {
    const destination = path.join(backup, file.path);
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    fs.copyFileSync(file.target, destination);
  }
}
fs.writeFileSync(path.join(backup, 'backup-manifest.json'), JSON.stringify({ newFiles: pending.filter(file => file.oldHash === null).map(file => file.path), files: pending.map(file => file.path) }, null, 2));
for (const file of pending) {
  fs.mkdirSync(path.dirname(file.target), { recursive: true });
  fs.writeFileSync(file.target, file.replacement);
}
console.log(`Applied ${pending.length} files. Backup: ${backup}`);
console.log('Next: deploy the backend, rebuild/sync Android, run the Android smoke test, and publish the new signed release. See README.md.');
