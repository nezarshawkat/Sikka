# Verification

Source baseline: `08eaccf68ca77f36f6b7a302002e3695cecd29e4` from the supplied GitHub repository.

## Passed locally

- 21 Vitest regression tests across 5 files. Tests exercise the actual on-device planner after accepting, editing and removing a route; authoritative snapshot selection; failed/denied storage; offline and malformed responses; unchanged manifests; backend snapshot membership/content revisions; geometry publication validation; and ad configuration timeout, switches, deduplication and background handling.
- Frontend TypeScript check (`tsc -p artifacts/sikka/tsconfig.json --noEmit`).
- Shared TypeScript library build (`tsc --build`).
- Production Vite web build. It retains the existing large-bundle warning.
- Production backend build (`node artifacts/api-server/build.mjs`). No production database was contacted or modified.
- Capacitor Android synchronization and inspection of the merged manifest: `com.sikkago.app.MainActivity`, the existing AdMob application ID and the SDK's AdActivity are present.
- Patch whitespace check.
- Apply script on a clean source copy: preflight, application, repeated application, and refusal of a conflicting local edit.

The full backend TypeScript check remains red on existing repository errors: **37 error entries in the untouched baseline, 33 after this patch, with no new error entries** after normalizing source line positions. The production backend build and targeted publication tests pass. The remaining errors are outside the changed route publishing code; this ZIP does not claim a clean repository-wide backend typecheck.

## Android build and device testing

The native build result is recorded in `android-build-result.txt`.

The Android instrumentation smoke tests and API 29/35 GitHub workflow are included. They check cold startup, a rendered WebView, and ad plugin calls from a bridge-like background thread. **They have not been executed on an emulator or physical phone in this session.** A successful compilation is not a device crash reproduction.

No signed AAB was created: the release keystore stays in your existing GitHub secrets. No deployment or Play upload was performed. No Play Console crash trace, live AdMob account diagnostics, or authenticated production database was available. Live ad fill and the exact reported Play crash therefore still need validation through Play internal testing.

Use the README's device checklist after deploying both the backend and the new Android release.
